const ctx1 = document.getElementById('chart1');

new Chart(ctx1, {
  type: 'bar',
  data: {
    labels: ['Grade 10', 'Grade 9', 'Grade 8', 'Grade 7'],
    datasets: [{
      label: 'participants',
      data: [130, 150, 140, 120],
      backgroundColor: ['blue', 'red', 'yellow', 'green']
   }]
  },
  options: {
    plugins: {
      legend: {
        display: false
      },
      title: {
        display: false,
        text: 'Participants by Grade'
      }
    }
  }
});

const ctx2 = document.getElementById('chart2');

new Chart(ctx2, {
  type: 'pie',
  data: {
    labels: ['Children', 'Students', 'Parents/Guardians'],
    datasets: [{
      data: [85, 527, 583]
    }]
  }
});